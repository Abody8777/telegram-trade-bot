const { Telegraf } = require('telegraf');

// استبدل التوكن بالتوكن الخاص بك
const bot = new Telegraf(process.env.BOT_TOKEN);

bot.start((ctx) => ctx.reply('أهلاً بك في بوت التداول 📈'));
bot.command('price', (ctx) => {
    // مثال: رد ثابت، لاحقًا ممكن نربطه بأسعار فعلية
    ctx.reply('🚀 سعر العملة الآن هو: 27,350 دولار');
});

bot.launch();
