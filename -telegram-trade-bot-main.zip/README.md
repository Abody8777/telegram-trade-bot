# Telegram Trade Bot

بوت بسيط للتنبيهات في تيليجرام مبني باستخدام telegraf.js